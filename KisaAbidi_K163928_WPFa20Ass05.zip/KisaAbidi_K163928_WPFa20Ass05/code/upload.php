<?php
    if (!file_exists('upload')) {
        mkdir('upload', 0777, true); 
    }

    if(isset($_FILES['file']["name"])){
        $file = $_FILES['file']["name"];
        move_uploaded_file($_FILES['file']['tmp_name'],"upload/".$file);
        echo "Successfully Uploaded!";
    }

?>
